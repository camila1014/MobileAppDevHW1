//==============================================================================
// PROGRAMMER:      Camila Aichele
// PANTHER ID:      6246396
//
// CLASS:           COP 4655
// SECTION:         RVC
// SEMESTER:        Spring 2023
// CLASSTIME:       Online
// Assignment:      Homework 1
// DUE:             2/7/2023
// CERTIFICATION:   I certify that this work is my own and that none of it is
//                  the work of any other person
//=============================================================================

import UIKit
import Darwin
import Foundation

//Step 1
print("-----------------")
print("Step 1")
print("-----------------")

let sides = 34.234
print("Sides:\t\t\t", sides)
print("Square Area:\t",sides*sides)

//Step 2
print("-----------------")
print("Step 2")
print("-----------------")

let height = 210
print("Height:\t\t\t", height)
let width = 283.2
print("Width:\t\t\t", width)
print("Perimeter:\t\t",2*(height+Int(width)))

//Step 3
print("-----------------")
print("Step 3")
print("-----------------")

let diameter = 4
print("Diameter:\t\t", diameter)
let cylinderHeight = 7.3
print("Height:\t\t\t", cylinderHeight)

let radius = diameter/2
let pi = 3.14159

print("Volume:\t\t\t",(pi*((Double(radius))*(Double(radius))*cylinderHeight)))

//Step 4
print("-----------------")
print("Step 4")
print("-----------------")

print("Diameter:\t\t", diameter)
print("Height:\t\t\t", cylinderHeight)

let surfaceArea1 = 2*pi*(Double(radius))*(Double(height))
let surfaceArea2 = 2*pi*(Double(radius))*(Double(radius))
let surfaceArea3 = surfaceArea1+surfaceArea2

print("Surface Area:\t", surfaceArea3)

//Step 5
print("-----------------")
print("Step 5")
print("-----------------")

let x = 3.932
print("x:\t\t\t\t",x)
let y = 21.245
print("y:\t\t\t\t",y)
let z = 0.3922001
print("z:\t\t\t\t",z)

let e = 2.71828

let step1 = y*(pow(e, 3))
let step2 = step1.squareRoot()
let step3 = 2*step2
let step4 = pow(y, z)
let step5 = step4+4
let numerator = step3/step5

let step6 = 3+y
let step7 = pow((x+42.2), 5)
let denominator = step5*step6

let step8 = x*y*(pow(z, 3))
let z3 = pow(z, 3)
let step9 = step8+4
let step10 = step9.squareRoot()
let step11 = step10+18

let step12 = numerator/denominator

let results = step12+step11

//round four decimal places
let roundResults = round(results * 10000) / 10000.0

print("z^3:\t\t\t", z3)
print("(x + 42.2)^5:\t", step7)
print("results:\t\t", roundResults)

